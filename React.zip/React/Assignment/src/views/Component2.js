import React from "react";

function Component2()
{
    return <h1>Component2</h1>
}

export default Component2;