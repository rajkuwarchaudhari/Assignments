import React from "react";

function Component1()
{
    return <h1>Component1</h1>
}

export default Component1;