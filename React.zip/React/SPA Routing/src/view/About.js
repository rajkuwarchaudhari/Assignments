import React from "react";
import { Component } from "react";
class About extends Component{
    render(){
        return(
            <div>
                <div><h1>This is about page</h1></div>
             <center>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQao77EgXjKFkAIBaBvNlQ6AzjhR8_9Ck_CNA&usqp=CAU" height="300px" width="400px"></img>
</center>
     </div>

        );
    }
}
export default About;