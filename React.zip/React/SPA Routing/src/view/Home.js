import React from "react";
import { Component } from "react";
class Home extends Component{
    render(){
        return(
            <div><h1>This Home page</h1>
            <div>
                <center>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSShGrK9oDE8C5mEEvgCs3GP_7lFXpIYpEbjA&usqp=CAU" height="300px" width="400px"></img>
                </center>
                </div>
            </div>
        );
    }
}
export default Home;