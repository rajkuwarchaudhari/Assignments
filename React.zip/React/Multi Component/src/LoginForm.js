
import React, {Component} from 'react';
class LoginForm extends Component
{
  render()
  {
    return (
        <div className='loginform'>
            <form>
                <label>Email<input type="text" /></label>
                <br />
                <label>Password<input type="password" /></label> 
                <br />
                <input type="submit" value="Login" />
            </form>
        </div>

    );
  }
}
export default LoginForm