
import React, {Component} from 'react';
class Testimonial extends Component
{
  render()
  {
    return (
        <div className='testimonial'>
            <ul>
            <li>The best place to work ranked again in 2022</li>          

            </ul>
        </div>

    );
  }
}
export default Testimonial