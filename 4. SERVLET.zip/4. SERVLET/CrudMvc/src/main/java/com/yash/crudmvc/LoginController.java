package com.yash.crudmvc;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.yash.dao.LoginDao;
import com.yash.bean.Login;

@Controller
@RequestMapping("/")
public class LoginController {
	@Autowired
	LoginDao dao;
	  @RequestMapping("/loginform")    
	    public String showform(Model m){    
	        m.addAttribute("command", new Login());  
	        return "loginform";   
	    }    
	  @RequestMapping(value="/save",method = RequestMethod.POST)    
	    public String save(@ModelAttribute("login") Login login){    
	        dao.save(login);    
	        return "redirect:/viewlogin";   
	    }    
	  @RequestMapping("/viewlogin")
	  public String viewlogin(Model m){    
	        List<Login> list=dao.getLoginDetails();    
	        m.addAttribute("list",list);  
	        return "viewlogin";    
	    }    
	  @RequestMapping(value="/editlogin/{username}")    
	    public String edit(@PathVariable String username, Model m){    
	        Login log=dao.getLoginById(username);    
	        m.addAttribute("command",log);  
	        return "logineditform";    
	    }    
	  @RequestMapping(value="/editsave",method = RequestMethod.POST)    
	    public String editsave(@ModelAttribute("log") Login log){    
	        dao.update(log);    
	        return "redirect:/viewlogin";    
	    }    
	     
	    @RequestMapping(value="/deletelogin/{username}",method = RequestMethod.GET)    
	    public String delete(@PathVariable String username){    
	        dao.delete(username);    
	        return "redirect:/viewlogin";    
	    }     
}
