package com.org.yash.DAO;


import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.org.yash.User;

public class UserDAO {
	private HibernateTemplate hibernateTemplate;
	
	
public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}


	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

@Transactional
public int saveUser(User user)
{
	int id=(Integer)this.hibernateTemplate.save(user);
	return id;
}
public List<User> getUser()
{
	List<User> lst=this.hibernateTemplate.loadAll(User.class);
	return lst;
}
public User getDataById(int id)
{
	User u=this.hibernateTemplate.get(User.class,id);
	return u;
}
@Transactional
public void delete(int id)
{
	
	User u=getDataById(id);
	if(u==null) return;
	this.hibernateTemplate.delete(u);
}

@Transactional
public void update(User user)
{
this.hibernateTemplate.update(user);	
}
}