package com.org.yash;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
private String email;
private String name;
private int age;
/*private Address address;

public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}*/


public String getEmail() {
	return email;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public void setEmail(String email) {
	this.email = email;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}


/*
@Override
public String toString() {
	return "User [id=" + id + ", email=" + email + ", name=" + name + ", age=" + age + ", address=" + address + "]";
}
*/
}
