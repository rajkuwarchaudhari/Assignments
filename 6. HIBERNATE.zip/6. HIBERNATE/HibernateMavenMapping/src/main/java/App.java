
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.Service;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.Session;

public class App 
{
	private static SessionFactory factory; 

    public static void main( String[] args ) throws Exception
    {
    	
    	StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
    	Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();
    	factory=meta.getSessionFactoryBuilder().build();
    	
    	Address ad=new Address();
    	ad.setArea("Saandipani nagar");
    	ad.setCity("Ujjain");
    	ad.setPinCode(456006);
    	ad.setState("M.P.");
    	Employee emp=new Employee();
    	emp.setName("yash");
    	emp.setAddress(ad);
    	int id=addData(emp);
    	System.out.println("Id :"+id);
	}
    public static void addAddress()
    {
    	
    }
    public static int addData(Employee emp) throws Exception
    {
    	Session session=factory.openSession();
    	Transaction tx=null;
    	Integer empid=null;
    	tx=session.beginTransaction();
    	empid=(Integer)session.save(emp);
    	tx.commit();
    	return empid;
    	
    }
}
