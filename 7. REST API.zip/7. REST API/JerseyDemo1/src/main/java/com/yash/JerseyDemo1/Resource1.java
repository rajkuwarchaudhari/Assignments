package com.yash.JerseyDemo1;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Resource1 {
private String name;
private int marks;
public Resource1()
{
this.name="";
this.marks=0;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public int getMarks() {
return marks;
}
public void setMarks(int marks) {
this.marks = marks;
}

}