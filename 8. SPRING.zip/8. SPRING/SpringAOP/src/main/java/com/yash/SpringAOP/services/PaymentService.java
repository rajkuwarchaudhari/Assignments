package com.yash.SpringAOP.services;

public interface PaymentService {

	public void makePayment();

}