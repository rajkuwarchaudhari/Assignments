package com.yash;
public class Employee
{  
  private String name;
  private String age;

  
  public Employee()
  {
	System.out.println("Default Constructor");  
  }

  
  public Employee(String name, String age) 
  {
    this.name = name;
    this.age = age;
  }

  
  @Override
  public String toString() 
  {  
    return "Employee {" + "name='" + name + '\'' + ", age='" + age + '\'' + '}';
  }
}