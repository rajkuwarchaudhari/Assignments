package springbeanfactory;

import springbeanfactory.Employee;import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;public class App 
{ public static void main(String[] args) 
{
	System.out.println("Welcome");
	//Using Bean Factory as a IOC Container
	Resource res= new ClassPathResource("applicationcontext.xml");
	BeanFactory fac=new XmlBeanFactory(res);
	Employee e=(Employee) fac.getBean("employee");
	System.out.println(e);
}
}


