package com.yash.springjdbc;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.dao.EmployeeDao;
import com.yash.springjdbc.entities.Employee;

public class App {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		EmployeeDao emdao = context.getBean("EmployeeDao", EmployeeDao.class);
		System.out.println("Login");
		System.out.println("Enter the username");
		String user = sc.nextLine();
		System.out.println("Enter the password");
		String pass = sc.nextLine();

		if (user.equals("Rajkuwar") && pass.equals("Rajkuwar123")) 
		{
			while (true) {
				System.out.println("Enter the number to perform operation");
				System.out.println("1 for inserting data");
				System.out.println("2 for updating data");
				System.out.println("3 for deleting data");
				System.out.println("4 for exit");
				String choice = sc.nextLine();

				switch (choice) {

				case "1": {
					System.out.println("Enter the employee name: ");
					String empname = sc.nextLine();

					System.out.println("Enter the email: ");
					String emailid = sc.nextLine();

					System.out.println("Enter the date of birth: ");
					String dob = sc.nextLine();

					System.out.println("Enter the contact number: ");
					String contactno = sc.nextLine();

					System.out.println("Enter the salary: ");
					int salary = sc.nextInt();

					Employee e = new Employee(empname, emailid, dob, contactno, salary);
					int r = emdao.insert(e);
					System.out.println(r + "Record inserted successfully");
					break;
				}
				case "2": {
					System.out.println("Enter the employee name: ");
					String empname = sc.nextLine();

					System.out.println("Enter the email: ");
					String emailid = sc.nextLine();

					System.out.println("Enter the date of birth: ");
					String dob = sc.nextLine();

					System.out.println("Enter the contact number: ");
					String contactno = sc.nextLine();

					System.out.println("Enter the salary: ");
					int salary = sc.nextInt();

					Employee e = new Employee(empname, emailid, dob, contactno, salary);
					int r = emdao.updatedetails(e);
					System.out.println(r + "Record updated successfully");
					break;
				}
				case "3": {
					System.out.println("Enter the name: ");
					String empname = sc.nextLine();
					int r = emdao.deletedetails(empname);
					System.out.println(r + "Record deleted successfully");
					break;
				}
				case "4": {
					System.out.println("Exit");
					break;
				}
				default: {
					System.out.println("No matched operation");
					break;
				}
				}
			}
		}
	}
}
