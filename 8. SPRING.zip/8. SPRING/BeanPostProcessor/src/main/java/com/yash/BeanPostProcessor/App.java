package com.yash.BeanPostProcessor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args)
	{
		System.out.println("Spring AutoWiring injection ");
		 ApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		 
		 Message e=context.getBean("message",Message.class);
		 System.out.println(e);
	}
}