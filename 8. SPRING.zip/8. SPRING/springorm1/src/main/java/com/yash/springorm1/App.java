package com.yash.springorm1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springorm1.dao.StudentDAO;
import com.yash.springorm1.entities.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
        StudentDAO studao = context.getBean("studentDao", StudentDAO.class);
      // Student stu = new Student(3, "AJAY");
       // int msg = studao.insert(stu);
       // System.out.println(msg + "insertion done");
      //System.out.println(studao.getAllStudents());
       // studao.deleteDetails(2);
        Student stu1 = new Student(3,"Hardik");
        //stu1=studao.getStudentDetails(3);
        //System.out.println(stu1);
       
        studao.updateDetails(stu1);
        
        
        
        
    }
}
