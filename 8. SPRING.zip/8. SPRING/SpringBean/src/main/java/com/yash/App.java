package com.yash;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
   public static void main(String[] args) {
      AbstractApplicationContext context = new ClassPathXmlApplicationContext("/com/yash/Beans.xml");

      context.registerShutdownHook();
      SpringBean01 message = (SpringBean01) context.getBean("message");
      message.getMessage();
   }
}