package com.yash.springjdbc.dao;

import java.util.List;

import com.yash.springjdbc.entities.Employee;

public interface EmployeeDao {

	public int insert(Employee emp);

	public int updatedetails(Employee emp);

	public int deletedetails(int empid);
	
	public Employee selectDetails(int empid);

	public List<Employee> getAllDetails();


}