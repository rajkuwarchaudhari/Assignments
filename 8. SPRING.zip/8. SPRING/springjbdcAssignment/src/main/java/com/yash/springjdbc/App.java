package com.yash.springjdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.dao.EmployeeDao;
import com.yash.springjdbc.entities.Employee;

public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		EmployeeDao empdao = context.getBean("EmployeeDao", EmployeeDao.class);

//		Employee e = new Employee();
//		e.setId(103);
//		e.setName("Hardik");
//		e.setEmail("Hardik.jain@yash.com");
//		e.setDob("12/06/2000");
//		e.setContact("8767549834");
//		e.setSalary(20000);
//
//		int r = empdao.insert(e); // insert the details System.out.println(r +
//		System.out.println(r + "Employee details inserted successfully");

		/*
		 * int r=empdao.updatedetails(e); //update the details System.out.println(r +
		 * "Student added Successfully ");
		 */
		// System.out.println(r+"Student detail updated");
//		int r=empdao.deletedetails(111);//delete the details

//		Employee e = empdao.selectDetails(102);
//		System.out.println(e); //for retrival of data
		
		
		//for whole retrival of data
		List<Employee> emp=empdao.getAllDetails();
		for(Employee e:emp)
		{
		System.out.println(e);
		}
	}
}