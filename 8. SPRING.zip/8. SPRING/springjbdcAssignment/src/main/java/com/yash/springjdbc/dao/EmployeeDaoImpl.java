package com.yash.springjdbc.dao;

import com.yash.springjdbc.entities.*;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class EmployeeDaoImpl implements EmployeeDao {

	private JdbcTemplate jdbctemp;

	public int insert(Employee emp) {

		String q = "insert into employee(id,name,email,dob,contact,salary) values(?,?,?,?,?,?)";
		int msg = this.jdbctemp.update(q, emp.getId(), emp.getName(), emp.getEmail(), emp.getDob(), emp.getContact(),
				emp.getSalary());
		return msg;
	}

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

	public int updatedetails(Employee emp) {
		// update details of student
		String q = "update Employee set salary=? where id=?";
		int msg = this.jdbctemp.update(q, emp.getSalary(), emp.getId());
		return msg;
	}

	public int deletedetails(int empid) {
		// TODO Auto-generated method stub
		String q = "delete from student where id=?";
		int msg = this.jdbctemp.update(q, empid);

		return msg;

	}

	@Override
	public Employee selectDetails(int empid) {
		// TODO Auto-generated method stub
		String q = "select * from employee where id=?";
		RowMapper<Employee> rowmapper = new RowMapperimpl();
		Employee employee = this.jdbctemp.queryForObject(q, rowmapper, empid);

		return employee;
	}

	public List<Employee> getAllDetails() 
	{
		// TODO Auto-generated method stub
		String q="select * from employee";
		List<Employee> emp=this.jdbctemp.query(q,new RowMapperimpl());
		return emp;

		}
}