package com.yash.springormCrud;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springormCrud.dao.StudentDAO;
import com.yash.springormCrud.entities.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		StudentDAO studao = context.getBean("studentDao", StudentDAO.class);
//		Student stu = new Student(103, "Yukta");
//		int msg = studao.insert(stu);// for insertion 
//		System.out.println(msg + "insertion done");
//		System.out.println(studao.getAllStudents());//for getting details
//		studao.deleteDetails(103);//for delete
		Student st=new Student(104,"rajkuwar");//update
		studao.updateDetails(st);

	}
}
