package springautowiring;

public class A {
	B b;
	A()
	{
		System.out.println("Class A Constructor");
	}
	public B getB() {
		return b;
	}
	public void setB(B b) {
		this.b = b;
	}
	
	
 void print()
 {
	 System.out.println("CLASS A RUNNING");
 }
 void display()
 {
 	print();
 	b.print();
 }
}