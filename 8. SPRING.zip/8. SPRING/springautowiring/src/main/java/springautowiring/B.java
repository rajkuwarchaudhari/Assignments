package springautowiring;

public class B {
B()
{
 System.out.println("class B Constructor");	
}
void print()
{
	System.out.println("B CLASS RUNNING");
}
}
