package springautowiring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main 
{
 public static void main(String args[])
 {
	 System.out.println("Spring AutoWiring injection ");
	 ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
	 
	 A a=context.getBean("a",A.class);
	 a.display();
 }
}