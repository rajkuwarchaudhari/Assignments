package lifeCycleWithAnnotations;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import lifeCycleUsingXML.HelloWorld;

//Driver class
public class test {

	public static void main(String[] args)
 {
	 ApplicationContext context= new ClassPathXmlApplicationContext("lifeCycleUsingXML/Bean.xml");

	HelloWorld obj=(HelloWorld) context.getBean("helloworld");
	 obj.getMessage();
	 ((ConfigurableApplicationContext) context).registerShutdownHook();
    
 }
}