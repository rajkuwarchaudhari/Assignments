package lifeCycleWithAnnotations;

public class HelloWorld {
	private String Message;
	 
   
    public String getMessage() {
    	System.out.print("message is : "+Message);
		return Message;
	}

	public void setMessage(String message) {
		this.Message = Message;
	}

	public void init() throws Exception
    {
        System.out.println("Bean is going through init method");
    }
 
    public void destroy() throws Exception
    {
        System.out.println("Bean to destroy method");
    }
}