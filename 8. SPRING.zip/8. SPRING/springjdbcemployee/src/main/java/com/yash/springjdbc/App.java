package com.yash.springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.dao.EmployeeDao;
import com.yash.springjdbc.entities.Employee;

public class App
{
public static void main( String[] args )
{
ApplicationContext context=new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
EmployeeDao emdao=context.getBean("EmployeeDao",EmployeeDao.class);
Employee e=new Employee();
e.setEmpname("Raj");
e.setEmailid("raj@yash.com");
e.setDob("20/08/2001");
e.setContactno("9098995679");
e.setSalary(50000);

int r=emdao.insert(e);
//int r=emdao.updatedetails(e);
//System.out.println(r + "Employee details updated Successfully ");
System.out.println(r + "Employee added Successfully ");
//int r=emdao.deletedetails("Ravi");
//System.out.println(r + "Employee deleted Successfully ");

}
}


