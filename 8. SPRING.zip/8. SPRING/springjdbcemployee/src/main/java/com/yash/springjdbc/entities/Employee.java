package com.yash.springjdbc.entities;

public class Employee {
private String empname;
private String emailid;
private String dob;
private String contactno;
private int salary;
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}

public Employee(String empname, String emailid, String dob, String contactno, int salary) {
	super();
	this.empname = empname;
	this.emailid = emailid;
	this.dob = dob;
	this.contactno = contactno;
	this.salary = salary;
}

public String getEmpname() {
	return empname;
}
public void setEmpname(String empname) {
	this.empname = empname;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getContactno() {
	return contactno;
}
public void setContactno(String contactno) {
	this.contactno = contactno;
}
public double getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
@Override
public String toString() {
	return "Employee [empname=" + empname + ", emailid=" + emailid + ", dob=" + dob + ", contactno=" + contactno
			+ ", salary=" + salary + "]";
}

}