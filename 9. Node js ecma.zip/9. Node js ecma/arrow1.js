//arrow function demo
var x=(a,b)=> a+b;

console.log("sum "+x(10,22));

var msg=()=>{ console.log("hello everyone");} 

msg();
var si=(p,r,t)=> {
	 return (p*r*t)/100;
	 }
	 
	console.log(si(1000,5,5)); 
// single parameter in arrow function 

var u= m=>" value you passed "+m;

console.log(u(1234));
console.log(u("sunil kumar"));
console.log(u(12.0034));
	
const myfun = (x)=>x*x; 

console.log(myfun(10));	