for(i=1; i<=10; i++){
    // let's divide the value by 2.
    // if the remainder is zero then it's an even number.
    if(i % 2 == 0){
    console. log(i);
    
    //creating a multiplication table
for(let j = 1; j <= 10; j++) {

    // multiply i with number
    const result = j * i;

    // display the result
    console.log(`${i} * ${j} = ${result}`);
    }
}
}