var carlist = ['maruti suzuki','tata' ,' renault' ,'bmw'];
var [car1,car2,car3,car4]= carlist;
console.log(car2);
console.log(car4);
var [car11,,,car14]= carlist;
console.log(car11);
console.log(car14);