// const pass_field= document.querySelector(".pass-key");
// const showBtn= document.querySelector(".show");
// showBtn.addEventListener("click", function()
// {
//     if(pass_field.type === "password"){
//         pass_field.type="text";
//         showBtn.textContent="HIDE";
//         showBtn.style.color="#3498db";
//     }
//     else{
//         pass_field.type="password";
//         showBtn.textContent="Show";
//         showBtn.style.color="#222";
//     }
// })




// function validation() {
//     var form = document.getElementById("form");
//     var email = Document.getElementById("email").value;
//     var text = document.getElementById("text");
//     var pattern = /^[^]+@[^]+\.[a-z]{2,3}$/;

//     if (email.match(pattern)) {
//         form.classList.add("valid")
//         form.classList.remove("invalid")
//         text.innerHTML = " Your Email is valid.";
//         text.style.color = "#00ff00";
//     }
//     else {
//         form.classList.remove("valid")
//         form.classList.add("invalid")
//         text.innerHTML = " Your Email is Invalid please enter valid email.";
//         text.style.color = "#00ff00";
//     }
//     if (email == "") {
//         form.classList.remove("valid")
//         form.classList.remove("invalid")
//         text.innerHTML = "";
//         text.style.color = "#00ff00";
//     }
// }