import java.lang.Class;
import java.lang.reflect.*;

class Dog
{
	public void display()
	{
		System.out.println("hello");
	}
}
public class AnimalRefect extends Dog
 {
  public void display()
  {
    System.out.println("Dog is barking");
  }
}