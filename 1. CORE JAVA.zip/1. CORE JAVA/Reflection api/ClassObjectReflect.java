class A{}
interface b{}
class ClassObjectReflect
{
	public static void main(String srgs[]) throws Exception
	{
		Class c=Class.forName("A");
		System.out.println(c.getName());
		Class c1=Class.forName("A");
		System.out.println(c.isInterface());
		Class c2=Class.forName("b");
		System.out.println(c2.isInterface());
		
		//for isArray
		Class<int[]> c3 = int[].class;
        System.out.println(c3.isArray());
		
		//for Check isPrimitive
		boolean num = int.class.isPrimitive();
        System.out.println(num);

        num = int[].class.isPrimitive();
        System.out.println(num);
	}
}
