class RefelctionDemo 
{
	public static void main(String[] args) 
	{
		try 
		{
			Dog d1 = new Dog();

			Class obj = d1.getClass();

			String name = obj.getName();
			System.out.println("Name: " + name);
			
			
			Class c = boolean.class;   
			System.out.println(c.getName());  
  
			Class c2 = AnimalRefect.class;   
			System.out.println(c2.getName());  
      
		
		}

		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}