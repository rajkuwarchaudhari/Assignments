class Amstrongtry
{
	public static void main(String args[])
	{
		int no=153;
		int temp=no, length=0;
		while(temp!=0)
		{
			length=length+1;
			temp=temp/10;
		}
		int rem,temp2=no,sum=0;
		while(temp2!=0)
		{
			int mul=1;
			rem=temp2%10;
			for(int i=1;i<=length;i++)
			{
				mul=mul*rem;
			}
			sum=sum+mul;
			temp2=temp2/10;
		}
		if(sum==no)
		{
			System.out.println("it is an armstrong number");
		}
		else
		{
			System.out.println("not an armstrong number");
		}
	}
	
}


	