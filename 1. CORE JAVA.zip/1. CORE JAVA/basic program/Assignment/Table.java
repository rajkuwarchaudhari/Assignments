class Table{
	public static void main(String args[])
	{
		int a=Integer.parseInt(args[0]);
		for(int i=1;i<=10;i++)
		{
			int b=a*i;
			
			System.out.println(b);
			//System.out.println(a+ "*"+i+"="+a*i);
		}
	}
}
