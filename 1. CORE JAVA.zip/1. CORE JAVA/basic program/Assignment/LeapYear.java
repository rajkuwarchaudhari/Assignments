class LeapYear{
	public static void main(String args[]){
		int a=Integer.parseInt(args[0]);
		if(((a%4==0) && (a%100!=0))|| (a%400==0))
		{
			System.out.println("year is leap");
		}
		else{
			System.out.println("Year is not leap");
		}
	}
}
