class SwappingTwo
{
	public static void main(String args[])
	{
		int a=2,b=3;
		int temp;
		temp=a;
		a=b;
		b=temp;
		System.out.println(a);
		System.out.println(b);
	}
}
		
