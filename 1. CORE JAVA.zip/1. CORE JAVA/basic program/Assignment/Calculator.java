class Calculator
{
	public static void main(String args[]){
		double a,b;
		a=Double.parseDouble(args[0]);
		b=Double.parseDouble(args[1]);
		char ch;
		ch=args[2].charAt(0);
		double c;
		switch(ch)
		{
			case '+':
			    c=a+b;
				System.out.println(c);
			    break;
			case '-':
			    c=a-b;
				System.out.println(c);
			    break;
			case '*':
			    c=a*b;
				System.out.println(c);
			    break;
			case '/':
			    c=a/b;
				System.out.println(c);
			    break;
			default:
			System.out.println("wrong selection");
			
		}
	}
}

			