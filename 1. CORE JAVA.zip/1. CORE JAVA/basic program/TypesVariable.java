class TypesVariable{
	int a=20; //instance
	static int b=30; //static
	void add(){
		int c;//local
		c=a+b;
		System.out.println(c);
	}
	public static void main(String [] args)
	{
		TypesVariable obj1=new TypesVariable();// obj creation
		//a.add();
		System.out.println(obj1.a);//20
		System.out.println(obj1.b);//30
		obj1.a=50;
		obj1.b=450;
		System.out.println(obj1.a);//50
		System.out.println(obj1.b);//450
		TypesVariable obj2=new TypesVariable();
		System.out.println(obj2.a);//20
		System.out.println(obj2.b);//450
	}
}


