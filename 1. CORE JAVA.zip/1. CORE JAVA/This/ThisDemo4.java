class ThisDemo4
{
	void bark(ThisDemo4 t)
	{
		System.out.println("dog is barking");
	}
	void run()
	{
		//bark(this);
		System.out.println("dog is running");
	}
	
	public static void main(String [] args)
	{
		ThisDemo4 t= new ThisDemo4();
		t.run();
	}
}

		