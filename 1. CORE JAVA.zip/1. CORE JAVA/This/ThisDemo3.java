class ThisDemo3
{
	ThisDemo3()
	{
		this(3);
		System.out.println("dog is barking");
	}
	ThisDemo3(int i)
	{
		//this();
		System.out.println("dog is eating food");
	}
	public static void main(String [] args)
	{
		ThisDemo3 t=new ThisDemo3();
	}
}
