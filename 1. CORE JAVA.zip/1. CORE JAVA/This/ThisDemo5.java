class Animal
{
	Animal(ThisDemo5 t5)
	{
		System.out.println("there are different Animals in this class");
	}
}
class ThisDemo5
{
	void barking()
	{
		Animal t=new Animal(this);// this use for the calling of Animal class constrctor
		System.out.println("dog is barking");
	}
	public static void main(String [] args)
	{
		ThisDemo5 t= new ThisDemo5();
		t.barking();
	}
}

		