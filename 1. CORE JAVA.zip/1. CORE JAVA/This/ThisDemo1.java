class Demo
{
	int i; // instance varible
	void setValue(int i)//Method with local varible
	{
		//i=i;//local and instance variable name are same so this will print the default value of i i.e 0
		this.i=i;
	}
	void show()//method
	{
		System.out.println(i); //instance
	}
}
class ThisDemo1
{
	public static void main(String [] args)
	{
		Demo d= new Demo();
		d.setValue(15);
		d.show();
	}
}
