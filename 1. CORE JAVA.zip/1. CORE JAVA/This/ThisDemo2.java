class ThisDemo2
{
	void display()
	{
		System.out.println("This is going to display something by the display method");
	}
	void show()
	{
		display(); // this is automatically add this keywords by the compiler
	}
	public static void main(String[] args)
	{
		ThisDemo2 t=new ThisDemo2();
		t.show();
	}
}

		