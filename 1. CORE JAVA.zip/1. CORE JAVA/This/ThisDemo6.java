class ThisDemo6
{
	ThisDemo6 a() // method is not void so that we can return the value
	{
		return this;
			}
	public static void main(String [] args)
	{
		ThisDemo6 td=new ThisDemo6();
		td.a();
	}
}
		