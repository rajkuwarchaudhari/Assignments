import java.awt.event.*;  
import javax.swing.*;    
public class JExample 
{
	public static void main(String[] args) 
	{
		//label 
		//JFramef=f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JFrame f= new JFrame("new page");  
		JLabel l1,l2;  
		l1=new JLabel("First Label.");  
		l1.setBounds(100,100, 100,100);  
		l2=new JLabel("Second Label.");  
		l2.setBounds(100,100, 100,100);  
		f.add(l1); f.add(l2);  
		f.setSize(300,300);  
		f.setLayout(null);  
		f.setVisible(true);
		
		final JLabel label = new JLabel();            
		label.setBounds(20,150, 200,50);  
		final JPasswordField value = new JPasswordField();   
		value.setBounds(100,75,100,30);   
		JLabel l3=new JLabel("Username:");    
        l3.setBounds(20,20, 80,30);    
        JLabel l4=new JLabel("Password:");    
        l4.setBounds(20,75, 80,30);    
        JButton b1 = new JButton("Login");  
        b1.setBounds(100,120, 80,30);    
        final JTextField text = new JTextField();  
        text.setBounds(100,20, 100,30);
		f.add(value); f.add(l3); f.add(label); f.add(l4); f.add(b1); f.add(text);  
		f.setSize(300,300);    
		f.setLayout(null);    
		f.setVisible(true);     
		b1.addActionListener(new ActionListener() 
		{  
            public void actionPerformed(ActionEvent e)
			{       
                String data = "Username " + text.getText();  
                data += ", Password: " + new String(value.getPassword());   
                label.setText(data); 
			}
		});			
		  
        JCheckBox checkBox1 = new JCheckBox("C++");  
        checkBox1.setBounds(100,100, 50,50);  
        JCheckBox checkBox2 = new JCheckBox("Java", true);  
        checkBox2.setBounds(100,150, 50,50);  
        f.add(checkBox1);  
        f.add(checkBox2);  
        f.setSize(400,400);  
        f.setLayout(null);  
        f.setVisible(true);   
        
		
		

		
    
	}
	
}
