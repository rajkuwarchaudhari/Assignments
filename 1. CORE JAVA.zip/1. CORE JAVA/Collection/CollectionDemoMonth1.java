import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Vector;
import java.util.HashSet;
import java.util.ListIterator;

public class CollectionDemoMonth1 
{
	public static void main(String[] args)
	{
		
		//--------------------ArrayList
		/*
		ArrayList <String> m=new ArrayList<String>();
		m.add("January");
		m.add("February ");
		m.add("March");
		m.add("April");
		m.add("May");
		m.add("June");
		m.add("July");
		m.add("August");
		m.add("September");
		m.add("October");
		m.add("November");
		m.add("December");
		
		//using System.out.pruntln
		System.out.println(m);
		System.out.println();
	
		//using iterator
		System.out.println("using iterator");
		Iterator i=m.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
			System.out.println();
			
		//using for each
		System.out.println("using foreach");
		for(String Month:m)
		System.out.println(Month);
		
		
		
		//---------------------------------	ListIterator
		System.out.println("usimg ListIterator");
		//using ListIterator
		ListIterator li=m.listIterator();
		li.next();
		li.next();
		li.next();
		while(li.hasPrevious())
		{
			System.out.println(li.previous());
		}
		
		li.set("Technologies");
		System.out.println(m);
		*/
		
		
		
		
		/*
		//-------------------------------------LinkedList
		LinkedList m=new LinkedList();  
		m.add("January");
		m.add("February ");
		m.add("March");
		m.add("April");
		m.add("May");
		m.add("June");
		m.add("July");
		m.add("August");
		m.add("September");
		m.add("October");
		m.add("November");
		m.add("December");  
		Iterator<String> itr=m.iterator();  
		while(itr.hasNext())
		{
			System.out.println(itr.next());  
		}  
		m.remove("May");
		System.out.println(m);
		Iterator i=m.descendingIterator();  
           while(i.hasNext())  
           {  
               System.out.println(i.next());  
           }  
		*/
		
		
		/*
		//-------------------------------------Vextor
		Vector<String> m=new Vector<String>();
		m.add("January");
		m.add("February ");
		m.add("March");
		m.add("April");
		m.add("May");
		m.add("June");
		m.add("July");
		m.add("August");
		System.out.println(m);
		m.addElement("September");//adding elements
		m.addElement("October");
		m.addElement("November");
		m.addElement("December");
		System.out.println(m);
		System.out.println(m.size());
		System.out.println(m.capacity());
		
		//check it is in the list or not
		if(m.contains("July"))  
            {  
               System.out.println("July is present at:" +m.indexOf("July"));  
            }  
            else  
            {  
               System.out.println("not present.");  
            }
		//getting first elements
		System.out.println(m.firstElement());
		System.out.println(m.lastElement());
		
		
		//removing elements
		System.out.println(m.remove("August"));
		System.out.println(m.remove(2));
		System.out.println(m);
		*/
		
		//---------------------HashSet
		HashSet<String> m=new HashSet<String>();
		m.add("January");
		m.add("February ");
		m.add("March");
		m.add("April");
		m.add("May");
		m.add("June");
		m.add("July");
		m.add("August");
		m.add("September");
		m.add("October");
		m.add("November");
		m.add("December");
		m.add("July");
		m.add("August");
		m.add("September");
		m.add("October");
		m.add("November");
		m.add("December");		
		
		Iterator<String> i=m.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());  
		}
		
		//remove
		m.remove("August");  
		System.out.println(m);
		
		
		

		
		
	}

}