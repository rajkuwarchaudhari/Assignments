import java.util.ArrayList;
import java.util.HashSet;

public class CollectionDemo1 
{
	public static void main(String[] args)
	{
		ArrayList <String> a=new ArrayList<String>();
		a.add("Mother");
		a.add("Father");
		a.add("Brother");
		/*HashSet h=new HashSet();
		h.add("technologies");
		h.add(30);*/
		for(String family:a)
		System.out.println(family);
		System.out.println(a);
		
	}

}