import java.util.Scanner;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapAssignment3 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		HashMap<String,Integer> cs = new HashMap<String,Integer>();
		cs.put("Rajkuwar", 654321);
		cs.put("Police", 100);
		cs.put("Fire", 109);
		cs.put("hospital" ,105);
		cs.put("Raj", 764532);
		System.out.println(cs);
		
		//checkig the value
		System.out.println("Enter the value to be checked");
		int val = sc.nextInt();
		if(cs.containsValue(val))
		{
			System.out.println("it exists");
        }
		else
		{
			System.out.println("not exists");
		}
		
		//checking the key 
		System.out.println("enter to check key:");
		String key = sc.next();
		if(cs.containsKey(key))
		{
			System.out.println("it exists");
		}
		else
		{
			System.out.println("not exists");
		}
		//for printing the all key and value
		/*Iterator i = cs.entrySet().iterator();
		while(i.hasNext())
		{
			Map.Entry m = (Map.Entry)i.next();
			System.out.println("the key: " + m.getKey() + " the value: "+ m.getValue());
		}*/
	}
}