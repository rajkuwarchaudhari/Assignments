import java.util.HashSet;
import java.util.Iterator;

class Country 
{
	HashSet<String> h = new HashSet<String>();
	
	public HashSet<String> saveCountryNames(String CountryName) 
	{
		h.add(CountryName);
		return h;
	}
	
	public String getCountry(String CountryName)
	{
		Iterator<String> i = h.iterator();
		
		while (i.hasNext()) 
		{
			if (i.next().equals(CountryName))
				
				return CountryName;
		}
		return null;
	}
}

public class SetQuestion1 {

	public static void main(String[] args)
	{	
		Country c = new Country();
		c.saveCountryNames("USA");
		c.saveCountryNames("INDIA");
		c.saveCountryNames("CANADA");
		c.saveCountryNames("PARIS");
		c.saveCountryNames("NEWYORK");

		System.out.println(c.getCountry("CANADA"));
		System.out.println(c.getCountry("PAKISTAN"));		
	}

}