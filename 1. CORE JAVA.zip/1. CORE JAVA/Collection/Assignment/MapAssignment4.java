import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
class MapAssignment4
{
	HashMap<String,String> m1 = new HashMap<String,String>();
	public Map<String,String> saveCountryCapital(String countryName, String capital)
	{
	   m1.put(countryName,capital);
	   return m1;
	}
	
	//for the value
	public String getCountryName(String capitalName)
	{
	  for (Map.Entry entry: m1.entrySet())
        {
            if (capitalName.equals(entry.getValue()))
			{
                return (String)entry.getKey();
            }
        }
        return null; 
	}
	
	//for key
	public String getCapitalName(String countryName)
	{
		System.out.println(m1);
		return m1.get(countryName); 
	}	
  
	//reverse the key and value
	public Map<String,String> getReverseMap()
	{
		HashMap<String,String> m2 = new HashMap<String,String>();
		for(Map.Entry<String,String> entry: m1.entrySet())
		{
			m2.put(entry.getValue(),entry.getKey());
		}
		System.out.println(m2);
		return m2;
	}
   
	public ArrayList<String> getArrayList()
	{
		ArrayList<String> l = new ArrayList<String>(m1.keySet());
		System.out.println(l);
		return l;	  
	}
	public static void main(String[] args)
	{
		MapAssignment4 obj1 = new MapAssignment4();
		obj1.saveCountryCapital("USA","Washingtone DC");
		obj1.saveCountryCapital("India","Delhi");
		obj1.saveCountryCapital("Belgium","Brussels");
		obj1.saveCountryCapital("Bhutan","Thimphu");
		System.out.println(obj1.getCapitalName("Belgium"));
		System.out.println(obj1.getCountryName("Brussels"));
		//reversing the key and value 
		System.out.println("reverse:"+ obj1.getReverseMap());
		System.out.println("Contry names:"+ obj1.getArrayList());
 }
}