import java.util.Scanner;
import java.util.HashSet;
import java.util.Iterator;

public class SetQuestion2 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		
		HashSet<String> hs = new HashSet<String> ();
		System.out.println("enter the name");
		String a=sc.next();
		hs.add("Welcome to	");
		hs.add("yash");
		hs.add("technologies");
		hs.add(a);
		
		Iterator<String> i = hs.iterator();
		while (i.hasNext())
			System.out.println(i.next());
	}

}