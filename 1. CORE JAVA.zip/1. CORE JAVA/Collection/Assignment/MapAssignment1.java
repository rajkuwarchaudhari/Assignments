import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Iterator;
import java.util.Set;

public class MapAssignment1
{

	public static void main(String[] args) 
	{
		Map<String, String> m = new HashMap<>();
		//inserting value and key
		m.put("Yash", "Technologies");
		m.put("Rajkuwar", "Chaudhari");
		m.put("hello", "world");
		m.put("weclxome", "to");
		
		Set<Entry<String, String>> s = m.entrySet();
		Iterator<Entry<String, String>> i = s.iterator();
		
		
		//key is present or not
		while (i.hasNext()) 
		{
			Map.Entry<String, String> m2 = i.next();
			
			if (m2.getKey().equals("Rajkuwar")) 
			{
				System.out.println("Key Rajkuwar Present");
				break;
			}
			
		}
		
    	s = m.entrySet();
		i = s.iterator();
		
		
		//value is present or not
		
		while (i.hasNext()) {
			Map.Entry<String, String> m2 = i.next();
			
			if (m2.getValue().equals("to"))
			{
				System.out.println("Value to is present");
				break;
			}
		}
		
		s = m.entrySet();
		i = s.iterator();
		
		//iterator
		while (i.hasNext()) 
		{
			Map.Entry<String, String> m2 = i.next();
			System.out.println(m2);
		}
	}

}
