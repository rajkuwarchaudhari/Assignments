import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

public class MapAssignment2 
{

	public static void main(String[] args) 
	{
		Properties pp = new Properties();
		
		
		pp.setProperty("Utter pradesh", "Lucknow");
		pp.setProperty("Madhya Pradesh", "Bhopal");
		pp.setProperty("Utrakhand", "Dehradun");
		pp.setProperty("West bangal", "Kolkatta");
		pp.setProperty("Himachal pradesh", "Shimla");
		pp.setProperty("Jharkhand", "Ranchi");
		pp.setProperty("Karnatka", "Bangluru");
		pp.setProperty("Goa", "Panaji");

		Set<Entry<Object, Object>> s = pp.entrySet();
		Iterator<Entry<Object, Object>> i = s.iterator();
		
		while (i.hasNext()) 
		{
			Entry<Object, Object> e = i.next();
			System.out.println(e);
		}
	}

}