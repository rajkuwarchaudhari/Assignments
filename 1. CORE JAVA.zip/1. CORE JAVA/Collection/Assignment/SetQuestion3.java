import java.util.Iterator;
import java.util.TreeSet;

public class SetQuestion3 
{

	public static void main(String[] args) 
	{
		
		TreeSet<String> ts = new TreeSet<String>();
		ts.add("Welcome");
		ts.add("to");
		ts.add("Yash");
        ts.add("Technologies");
		ts.add("Rajkuwar");
		System.out.println(ts);  
        Iterator i = ts.descendingIterator();

        while (i.hasNext())
			{
       			System.out.println(i.next());
        	}
		
		Iterator<String> i2 = ts.iterator();
		String s = "Rajkuwar";
		boolean res = false;
		
		while (i2.hasNext()) {
			if (i2.next().equals(s)) {
				res = true;
				break;
			}
		}
		System.out.println();
		if (res)
		{
			System.out.println(s +" --it is in the set");
		}
		else
		{
			System.out.println(s + "not in the set");
		}
	}

}