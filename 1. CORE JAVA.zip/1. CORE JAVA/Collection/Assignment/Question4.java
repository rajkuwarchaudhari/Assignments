import java.util.Scanner;
import java.util.Iterator;
import java.util.Vector;

class Employee
{
	private int id;
	private String name;
	private String address;
	private Double salary;
	
	public Employee(int id, String name, String address, Double salary) {
		this.id = id;
		this.name = name;
		this.address = address;
		this.salary = salary;
	}	

	public String toString() {
		return  id +name +address +salary;
	}
}

public class Question4
 {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		Vector<Employee> v = new Vector<>();
		System.out.println("enter the id");
		int id=sc.nextInt();
		System.out.println("enter name");
		String name=sc.next();
		System.out.println("enter address");
		String address=sc.next();
		System.out.println("enter salary");
		double salary=sc.nextDouble();
		
		v.add(new Employee(id,name,address,salary));
		v.add(new Employee(id,name,address,salary));
		
		Iterator<Employee> i = v.iterator();
		while (i.hasNext()) 
			System.out.println(i.next());
	}

}