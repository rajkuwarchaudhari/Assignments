class Chocolate
{
	Chocolate()
	{
		System.out.println("Dairy Milk");
	}
}

class SuperDemoConstructor extends Chocolate
{
	SuperDemoConstructor()
	{
		super(); // compiler automatically calls super
		System.out.println("5Star");
	}
	public static void main(String args[])
	{
		SuperDemoConstructor sc= new SuperDemoConstructor();
	}
}