class A
{
	void display()
	{
		System.out.println("i am in class A");
	}
}

class SuperDemoMethod extends A
{
	void display()
	{
		System.out.println("i m in main class");
	}
	void show()
	{
		display();
		super.display();
	}
	public static void main(String args[])
	{
		SuperDemoMethod sm=new SuperDemoMethod();
		sm.show();
	}
}