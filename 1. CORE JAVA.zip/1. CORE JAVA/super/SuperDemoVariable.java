class A
{
	int a=100;
}
class SuperDemoVariable extends A
{
	int a=200;
	void display(int a)
	{
		System.out.println(a);
		System.out.println(this.a);
		System.out.println(super.a);
	}
	public static void main(String args[])
	{
		SuperDemoVariable s=new SuperDemoVariable();
		s.display(300);
	}
}