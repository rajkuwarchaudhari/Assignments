import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.SequenceInputStream;
class MergeFileIntoThird
{
	public static void main(String args[]) throws IOException
	{
		FileInputStream f1=new FileInputStream("d:/yash/abc.txt");
		FileInputStream f2=new FileInputStream("d:/yash/xyz.txt");
		FileOutputStream f3=new FileOutputStream("d:/yash/merged.txt");
		SequenceInputStream s=new SequenceInputStream(f1,f2);
		int i;
		while((i=s.read())!=-1)
		{
			f3.write(i);//HELP TO PRINT the data
			System.out.println((char)i);
		}
		s.close();
		f1.close();
		f2.close();
		System.out.println("file merged");
	}
}

		