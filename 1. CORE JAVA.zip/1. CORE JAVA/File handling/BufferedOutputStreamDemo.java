import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.util.Scanner;
import java.io.Exception;
public class BufferedOutputStreamDemo
{
	public static void main(String args[])throws Exception
	{    
		Scanner sc=new Scanner(System.in);
		FileOutputStream fo=new FileOutputStream("d:/yash/abc.txt");    
		BufferedOutputStream bo=new BufferedOutputStream(fo);    
		   
		System.out.println("enter the string");
		String s=sc.next();
		byte obj[]=s.getBytes();    
		bo.write(obj);
		
		bo.close();    
		fo.close();    
		System.out.println("done with bufferedOutputStream");    
	}
}  