import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
public class DataInputStreamDemo

{
	public static void main(String args[]) throws IOException
	{
		FileInputStream f=new FileInputStream("d:/yash/yyy.txt");
		DataInputStream d=new DataInputStream(f);
		int a=d.readInt();
		char c=d.readChar();
		double db=d.readDouble();
		System.out.println(a);
		System.out.println(c);
		System.out.println(db);
		d.close();
		
	}
}
		