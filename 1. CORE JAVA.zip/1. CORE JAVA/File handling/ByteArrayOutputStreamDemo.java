import java.util.Scanner;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
class ByteArrayOutputStreamDemo
{
	public static void main(String[] args) throws IOException
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		String a = sc.nextLine();
		ByteArrayOutputStream b = new ByteArrayOutputStream();
		byte[] arr = a.getBytes();
		b.write(arr);
		String s = b.toString();
		System.out.println("output string ="+s);
		b.close();
	}
}
