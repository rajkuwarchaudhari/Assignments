import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.IOException;
class Employee implements Serializable
{
	int empId;
	String name;
	Employee(int empId, String name)
	{
		this.empId=empId;
		this.name=name;
	}
	public String toString()
	{
		return empId+ " " + name;
	}
}
	
class ObjectOutputStreamDemo
{
	public static void main(String args[]) throws Exception
	{
		Employee e=new Employee(145,"rajkuwar");
		System.out.println(e);
		File f=new File("d:/yash/abc.txt");
		ObjectOutputStream oo=new ObjectOutputStream(new FileOutputStream(f));
		oo.writeObject(e);
		oo.close();
	}
}