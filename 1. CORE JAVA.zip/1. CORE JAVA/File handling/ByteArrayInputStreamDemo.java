import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Scanner; 
class ByteArrayInputStreamDemo
{

  public static void main(String[] args) throws IOException
  {
	  Scanner s = new Scanner(System.in);
	  System.out.println("Enter the length of the array:");
	  int l = s.nextInt();
      byte a[] = new byte[l];
      System.out.println("Enter the elements of the array:");

      for(int i=0; i<l; i++ ) 
	  {
        a[i] = s.nextByte();
      } 
	  ByteArrayInputStream b = new ByteArrayInputStream(a);  
	  System.out.println("array are:");
	  int i = 0;  
	  while ((i = b.read()) != -1) 
	  { 
		
		System.out.println(i);
	  }
  }
}
	    
    
