import java.io.IOException;
import java.io.FileInputStream;
class FileIOAssignment2
{
	public static void main(String args[]) throws IOException
	{
		int sum=0;
		int a=0,e=0,i=0,o=0,u=0;
		FileInputStream f=new FileInputStream("d:/yash/abc.txt");
		int r;
		while((r=f.read())!=-1)
		{
			if((char)r=='a' || (char)r=='A')
			{
				++a;
				++sum;
			}
			if((char)r=='e' || (char)r=='E')
			{
				++e;
				++sum;
			}
			if((char)r=='i' || (char)r=='I')
			{
				++i;
				++sum;
			}
			if((char)r=='o' || (char)r=='O')
			{
				++o;
				++sum;
			}
			if((char)r=='u' || (char)r=='U')
			{
				++u;
				++sum;
			}
		}
		System.out.println("total vovels are:="+sum);
		System.out.println("time of a occur:="+a);
		System.out.println("time of e occur:="+e);
		System.out.println("time of i occur:="+i);
		System.out.println("time of o occur:="+o);
		System.out.println("time of u occur:="+u);
	}
}
			