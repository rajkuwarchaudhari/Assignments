import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.Scanner;

class Employee implements Serializable
 {
	private String name;
	private String department;
	private String designation;
	private double salary;
	
	public Employee()//non perametrized constructor
	{
	}
	
	public Employee(String name,String department,String designation,double salary)
	{
		this.name=name;
		this.department=department;
		this.designation=designation;
		this.salary=salary;
	}
	public String toString()
	{
		return name +""+ department+""+designation+""+salary;
	}
 }
public class EmployeeObjectSerializationDemo1
{	
	public static void main(String[] args) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		Employee emp = new Employee("rajkuwar","yash","trainee",13000);
		
		
		File f = new File("d:/yash/abc.txt");
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(emp);
		FileInputStream fis = new FileInputStream(f);
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
		emp=(Employee)ois.readObject();
		
		
		oos.close();
		ois.close();
	}
	System.out.println("successfully done");
	

}