import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.Scanner;

public class EmployeeObjectSerializationDemo implements Serializable
 {
	private String name;
	private String dep;
	private String des;
	private double salary;
	
	public String getName()
	{
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	public String getDepartment() 
	{
		return dep;
	}
	public void setDepartment(String dep) 
	{
		this.dep = dep;
	}
	public String getDesignation()
	{
		return des;
	}
	public void setDesignation(String des)
	{
		this.des = des;
	}
	public double getSalary()
	{
		return salary;
	}
	public void setSalary(double salary)
	{
		this.salary = salary;
	}
	public String toString() 
	{
		return "(name=" + name + ", department=" + dep + ", designation=" + des+ ", salary=" + salary + ")";
	}
	
	public static void main(String[] args) throws Exception
	{
		Scanner scan = new Scanner(System.in);
		EmployeeObjectSerializationDemo emp = new EmployeeObjectSerializationDemo();
		System.out.print("Enter name: ");
		emp.setName(scan.nextLine());
		System.out.print("Enter department: ");
		emp.setDepartment(scan.nextLine());
		System.out.print("Enter designation: ");
		emp.setDesignation(scan.nextLine());
		System.out.print("Enter salary: ");
		emp.setSalary(scan.nextDouble());
		scan.nextLine();
		
		
		FileOutputStream fos = new FileOutputStream("d:/yash/abc.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(emp);
		FileInputStream fis = new FileInputStream("d:/yash/abc.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		EmployeeObjectSerializationDemo emp2 = (EmployeeObjectSerializationDemo)ois.readObject();
		
		
		System.out.println("Name: " + emp2.getName());
		System.out.println("Department: " + emp2.getDepartment());
		System.out.println("Designation: " + emp2.getDesignation());
		System.out.println("Salary: " + emp2.getSalary());
		
		fos.close();
		oos.close();
		fis.close();
		ois.close();
	}

}