import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
class FileIOAssignment1
{
	public static void main(String args[]) throws IOException
	{
		int line=1;
		int charcount=0;
		int space=0;
		int wordcount=0;
		FileInputStream f=new FileInputStream("d:/yash/abc.txt");
		int i;
		while((i=f.read())!=-1)
		{
			if(i==32)
			{
				space++;
			}
			if(i==13)
			{
				++line;
			}
			if(i==13 || i==32)
				wordcount++;
			if((i>=97 && i<=122)||(i>=65 && i<=90))
				charcount++;
		}
		f.close();
		System.out.println("space=:"+space);
		System.out.println("lines=:"+line);
		System.out.println("character=:"+charcount);
		System.out.println("words=:"+wordcount);
	}
}
		