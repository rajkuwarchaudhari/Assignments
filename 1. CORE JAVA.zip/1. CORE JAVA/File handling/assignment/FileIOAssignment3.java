import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileIOAssignment3 
{

	public static void main(String[] args) throws IOException 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("file name");
		String f = sc.nextLine();
		System.out.println("character to count");
		char c = sc.nextLine().charAt(0);
		File fl = new File(f);
		int Count = 0;
		BufferedReader br = new BufferedReader(new FileReader(fl));
		
		int ch;
		do 
		{
			ch = br.read();
			
			if (ch >= 65 && ch <= 90) ch += 32;
			if (c >= 65 && c <= 90) c +=32;
			
			if (ch == c)
				Count++;
		} 
		while (ch != -1);		
		System.out.println(Count);
		br.close();
	}

}