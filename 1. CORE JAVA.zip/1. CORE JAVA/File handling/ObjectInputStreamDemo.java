import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.io.IOException;
class Employee implements Serializable
{
	int empId;
	String name;
	Employee(int empId, String name)
	{
		this.empId=empId;
		this.name=name;
	}
	public String toString()
	{
		return empId+ " " + name;
	}
}
	
class ObjectInputStreamDemo
{
	public static void main(String args[]) throws Exception
	{
		File f=new File("d:/yash/abc.txt");
		ObjectInputStream oi=new ObjectInputStream(new FileInputStream(f));
		Employee e=(Employee)oi.readObject();
		oi.close();
		System.out.println(e);
	
	}
}