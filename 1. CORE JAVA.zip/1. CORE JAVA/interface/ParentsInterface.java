interface Mother
{
	void cooking();
}
interface Father
{
	void job();
}
class ParentsInterface implements Mother,Father
{
	public void cooking()
	{
		System.out.println("My mother is making food for me");
	}
	public void job()
	{
		System.out.println("My father is a govt officer");
	}
	public static void main(String args[])
	{
		ParentsInterface p=new ParentsInterface();
		p.cooking();
		p.job();
	}
}