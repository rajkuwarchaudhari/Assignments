interface LibraryUser
{
	void registerAccount();
	void requestBook();
}
class KidUser implements LibraryUser 
{
	private int age;
	private String bookType;
	public void setAge(int age) 
	{
		this.age = age;
	}
	public void setBookType(String book) 
	{
		this.bookType = book;
	}
	public void registerAccount() 
	{
		if(age < 12)
			System.out.println("kid acc successfully done");
		else
			System.out.println("sorry your age is less than12");		
	}
	public void requestBook() 
	{
		if(bookType.equals("Kids"))
			System.out.println("book issues");
		else
			System.out.println("only kids book allowed");
	}
}
class AdultUser implements LibraryUser 
{
	private int age;
	private String bookType;
	
	public void setAge(int age) 
	{
		this.age = age;
	}
	public void setBookType(String book) 
	{	
		this.bookType = book;
	}
	public void registerAccount() 
	{
		if(age > 12)
			System.out.println("adult acc successfully registerd");
		else
			System.out.println("age must be >12");
	}
	public void requestBook() 
	{
		if(bookType.equals("Fiction"))
			System.out.println("book issued");
		else
			System.out.println("only adult book can be issued");
	}
}
public class LiberaryAssignment 
{
	public static void main(String[] args) 
	{
		KidUser k = new KidUser();
		k.setAge(10);
		k.setBookType("Kids");
		k.registerAccount();
		k.requestBook();
		k.setAge(14);	
		k.setBookType("Fiction");		
		k.registerAccount();
		k.requestBook();
		System.out.println();
		
		AdultUser ad = new AdultUser();
		ad.setAge(5);
		ad.setBookType("Kids");
		ad.registerAccount();
		ad.requestBook();
		ad.setAge(55);	
		ad.setBookType("Fiction");		
		ad.registerAccount();
		ad.requestBook();
		
	}

}