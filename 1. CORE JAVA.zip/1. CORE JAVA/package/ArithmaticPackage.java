import rajkuwar.Arithmatic;
class ArithmaticPackage
{
	public static void main(String args[])
	{
		Arithmatic obj=new Arithmatic();
		System.out.println("add operation:" + obj.add(3,5));
		System.out.println("mul operation:" + obj.mul(3,5));
		System.out.println("div operation:" + obj.mul(15,5));
		System.out.println("sub operation:" + obj.mul(8,5));
	}
}