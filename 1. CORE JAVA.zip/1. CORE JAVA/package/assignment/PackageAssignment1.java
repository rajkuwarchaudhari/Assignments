import test.FoundationAssignment;
public class PackageAssignment1
{
	public static void main(String args[])
	{
		FoundationAssignment f=new FoundationAssignment();
		System.out.println(f.val4=45);
		//System.out.println(f.val1=32);//private
		//System.out.println(f.val2=22);//default
		//System.out.println(f.val3=65);//protected
		
	}
}
