package com.automobiles
import java.util.Scanner;
import com.automobile.twowheeler.Hero;
import com.automobile.twowheeler.Honda;

public class PackageAssignment2
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter Model Number ");
		String mn=sc.nextLine();
		System.out.print("Enter Registration Number ");
		String rn=sc.nextLine();
		System.out.print("Enter Owner Number ");
		String on=sc.nextLine();
		System.out.print("Enter the speed ");
		int speed=sc.nextInt();
		Hero h = new Hero();
		
		System.out.println(h.getMN());
		System.out.println(h.getON());
		System.out.println(h.getRN());
		System.out.println(h.getSpeed());
		
		System.out.println();
		
		Honda hd = new Honda();
		System.out.print("Enter Model Number ");
		String mn=sc.nextLine();
		System.out.print("Enter Registration Number ");
		String rn=sc.nextLine();
		System.out.print("Enter Owner Number ");
		String on=sc.nextLine();
		System.out.print("Enter the speed ");
		int speed=sc.nextInt();
		
		System.out.println(hd.getMN());
		System.out.println(hd.getON());
		System.out.println(hd.getRN());
		System.out.println(hd.getSpeed());
			
	}

}