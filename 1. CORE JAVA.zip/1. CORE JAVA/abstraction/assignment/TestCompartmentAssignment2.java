import java.util.Random;
abstract class Compartment
{
	public abstract String notice();
}
class FirstClass extends Compartment
{
	public String notice()
	{
		return " 1st class";
	}
}
class Ladies extends Compartment
{
	public String notice()
	{
		return "ladies class";
	}
}

class General extends Compartment
{
	public String notice()
	{
		return "general";
	}
}
class Luggage extends Compartment{
	public String notice()
	{
		return "lugguage";
	}
}
	
class TestCompartmentAssignment2
{
	public static void main(String args[])
	{
		Compartment[] c=new Compartment[10];
		Random r=new Random();
		for(int i=0;i<10;i++)
		{
			int rn=r.nextInt((4-1)+1)+1;
			if(rn==1)
				c[i]=new Luggage();
			else if(rn==2)
				c[i]=new Ladies();
			else if(rn==3)
				c[i]=new General();
			else if(rn==4)
				c[i]=new FirstClass();
			
			
			System.out.println(c[i].notice());
		}
	}
}
			