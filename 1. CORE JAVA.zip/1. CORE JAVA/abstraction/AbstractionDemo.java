abstract class Mobile
{
	abstract void ringing();
	public void calling()
	{
		System.out.println("i am going to calling");
	}
}
class AbstractionDemo extends Mobile
{
	public void ringing()
	{
		System.out.println("Your Phone is ringing");
	}
	public static void main(String args[])
	{
	Mobile m=new AbstractionDemo();
	m.ringing();
	m.calling();
	}
}


