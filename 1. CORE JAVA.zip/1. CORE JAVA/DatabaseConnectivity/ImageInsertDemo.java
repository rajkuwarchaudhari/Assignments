import java.sql.*;
import java.io.*;

class ImageInsertDemo
{
  public static void main(String args[])
  {
	try
	{
		//load the driver
		Class.forName("com.mysql.jdbc.Driver");
		
		//create Connection
		String url= "jdbc:mysql://localhost:3306/ajay";
		String user="root";
		String pass="root";
		
		Connection con= DriverManager.getConnection(url,user,pass);
		
	  PreparedStatement pstmt = con.prepareStatement("INSERT INTO insertimage VALUES(?,?)");
      pstmt.setString(1, "ajay");
      //Inserting Blob type
      InputStream in = new FileInputStream("D:\\abc.png");
      pstmt.setBlob(2, in);
      //Executing the statement
      pstmt.execute();
      System.out.println("Record inserted......");
	  
		PreparedStatement ps=con.prepareStatement("select * from insertimage");  
		ResultSet rs=ps.executeQuery();  
		if(rs.next())
		{//now on 1st row  
              
		Blob b=rs.getBlob(2);//2 means 2nd column data  
		byte barr[]=b.getBytes(1,(int)b.length());//1 means first image  
              
		FileOutputStream fout=new FileOutputStream("D:\\abc.png");  
		fout.write(barr);  
              
		fout.close();  
		}//end of if  
        System.out.println("ok");  
		
	  con.close();
	}	  
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
  }
  
}