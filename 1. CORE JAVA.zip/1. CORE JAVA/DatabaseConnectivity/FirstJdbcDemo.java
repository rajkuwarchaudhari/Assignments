import java.sql.*;

class FirstJdbcDemo
{
  public static void main(String args[])
  {
	try
	{
		//load the driver
		Class.forName("com.mysql.jdbc.Driver");
		
		//create Connection
		String url= "jdbc:mysql://localhost:3306/ajay";
		String user="root";
		String pass="root";
		
		Connection con= DriverManager.getConnection(url,user,pass);
		
		if(con != null)
		{
			System.out.println("Connection established Successfully");
		}
		else
		{
			System.out.println("Connection not Created Successfully");
		}
		//Step 3: create querry
		String q= "Select * from employee";
		Statement st= con.createStatement();
        ResultSet set= st.executeQuery(q);

        //Step 4 : Procss the data
		while(set.next())
		{
			int id= set.getInt("EmpId");//(1)
			String name= set.getString("EmpName");//(2)
			
			System.out.println("Id "+id);
			System.out.println("Name "+name);
		}
		//Step 5:  Connection Close
		con.close();
	}	  
	
	catch(Exception e)
	{
		e.printStackTrace();
	}
  }
  
}