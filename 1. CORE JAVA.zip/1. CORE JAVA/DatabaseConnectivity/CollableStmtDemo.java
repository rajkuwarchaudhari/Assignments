import java.sql.*;  
class CollablestmtDemo
  {  
	public static void main(String args[])
	{  
		try{  
			Class.forName("com.mysql.jdbc.Driver"); 
			String url= "jdbc:mysql://localhost:3306/ajay";
			String user="root";
			String pass="root";
  
			Connection con=DriverManager.getConnection(url,user,pass); 
			
			CallableStatement stmt=con.prepareCall("{call employee(?,?)}");  
			stmt.setInt(1,105);  
			stmt.setString(2,"Amit");  
			stmt.execute();  
  
			System.out.println("success");  
			  
			  con.close();
			}
		catch(Exception e)
		{ 
		System.out.println(e);
		}  
  
  }  
}  