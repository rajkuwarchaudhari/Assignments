class OuterDemo
{
 class Inner
 {
  void show()
  {
  System.out.println("Inner class");
  }
 }
 public static void main(String args[])
 {
 OuterDemo o= new OuterDemo();
  OuterDemo1.Inner obj= o.newInner();
  obj.show();
 } 
}
// output = inner class
// for non-static inner class