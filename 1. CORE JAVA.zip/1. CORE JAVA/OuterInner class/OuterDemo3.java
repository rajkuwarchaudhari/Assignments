static class OuterDemo3
{
 static class Inner
 {
  void show()
  {
  System.out.println("Inner class");
  }
 }
 public static void main(String args[])
 {
  OuterDemo3.Inner obj= new OuterDemo3.Inner();
  obj.show();
 } 
}
