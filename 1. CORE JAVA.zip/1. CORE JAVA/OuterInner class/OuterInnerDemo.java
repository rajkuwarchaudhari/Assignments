class Outer
{
	static int a=10,b=5,c;
	void show1()
	{
		System.out.println("yash");
	}
	static class Inner //for static inner class use static keyword
	{
		void show()
		{
			c=a+b;
			System.out.println(c);
		}
	}
}
class OuterInnerDemo
{
	public static void main(String args[])
	{
		//Outer o=new Outer();//non static
		//Outer.Inner oi=o.new Inner();//non static
		Outer.Inner oi=new Outer.Inner();//static inner class
		oi.show();
		//o.show1();
	}
}