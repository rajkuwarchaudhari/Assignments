interface Demo
{
	void run();
	void math();
}
//without lamda expression
/*class ABC implements Demo
{
	//oveeride
	public void run()
	{
		System.out.println("i am running from without lamda");
	}
	public void math()
	{
		System.out.println("i am calling from without lamda");
	}
}*/
class LamdaDemo
{
	public static void main(String args[])
	{
		//without lamda
		/*Demo obj= new ABC();
		obj.math();
		obj.run();
		*/
		
		//with lamda
		Demo obj1=new  Demo()//annonyms class object
		{
			public void run()
			{
				System.out.println("i am running from lamda");
			}
			public void math()
			{
				System.out.println("i am calling from lamda");
			}
		};
		 obj1 .math();
	}
}
	
	