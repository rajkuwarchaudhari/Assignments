class ExceptionPrintingWays
{
	public static void main(String args[])
	{
		try
		{
			int a=20,b=0,c;
			c=a/b;
			System.out.println(c);
		}
		catch(Exception e)
		{
			//e.printStackTrace();
			//System.out.println(e);
			System.out.println(e.getMessage());
			
		}
	}
}
