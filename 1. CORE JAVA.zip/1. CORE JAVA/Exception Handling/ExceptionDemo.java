import java.io.FileInputStream;
class ExceptionDemo
{
	public static void main(String args[])
	{
		//unchecked exception
		
		System.out.println(2*3);
		System.out.println(2+3);
		System.out.println(2-3);
		//System.out.println(2/0);//runitme exception or Unchecked Exception
		System.out.println("Yash");
		int array[] = {1, 2, 3, 4, 5};
		System.out.println(array[7]);//ArrayIndexOutOfBoundsException ie. Unchecked Exception
		String s=null;
		System.out.println(s.length());//NullPointerException
	
	//checked exception
	/*
	//for handling the exception: we need of try-catch block where catch block only executed when there is any exception but try block can be executed anyways
	try{
		FileInputStream f=new FileInputStream("D:/abc.txt");//File not found ie. Checked Exception
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	Class.forName("com.mysql.jdbc.Driver"); //Class not found ie. Checked Exception
	*/
	System.out.println("byebye");//it only print when we handled the exception via Try-Catch block
	}
	
}	
