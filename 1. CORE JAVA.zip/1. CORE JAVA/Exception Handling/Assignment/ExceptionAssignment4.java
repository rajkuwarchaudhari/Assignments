class ExceptionAssignment4
{
	public static void main(String args[])
	{
		int arr[]= new int[5];
		int sum=0;
		try
		{
			for(int i=0;i<arr.length;i++)
			{
				arr[i]=Integer.parseInt(args[i]);
				sum=sum+arr[i];
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println(sum);
		System.out.println(sum/5);
	}
}

		
	