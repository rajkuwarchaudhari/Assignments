import java.util.Scanner;
class ExceptionAssignment2
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("no of elements in array");
		int a=sc.nextInt();
		int arr[]=new int[a];
		System.out.println("elements of array");
		try
		{
			for(int i=0;i<a;i++)
				arr[i]=sc.nextInt();
			System.out.println("enter the index");
			int idx=sc.nextInt();
			System.out.println(arr[idx]);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("java.lang.ArrayIndexOutOfBoundsException");
		}
	}
}
