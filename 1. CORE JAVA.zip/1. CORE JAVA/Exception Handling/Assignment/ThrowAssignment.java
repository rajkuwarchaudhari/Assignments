import java.util.Scanner;
class AvgExc extends RuntimeException
{
	AvgExc(String a)
	{
		super(a);
	}
}
class ThrowAssignment
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
			String name1="";
			String name2="";
			int subj11,subj12,subj13,subj21,subj22,subj23;
			try
			{
				System.out.println("Enter the 1st student name");
				name1=sc.next();
				System.out.println("Enter Math mark");
				subj11=sc.nextInt();
				
				if(subj11>100 || subj11<0)
					throw new AvgExc("Number is invalid");
				System.out.println("Enter English mark");
				subj12=sc.nextInt();
				if(subj12>100 || subj12<0)
					throw new AvgExc("Number is invalid");
				System.out.println("Enter Science mark");
				subj13=sc.nextInt();
				if(subj13>100 || subj13<0)
					throw new AvgExc("Number is invalid");
				
				System.out.println("Enter the 2nd Student name");
				name2=sc.next();
				System.out.println("Enter Math mark");
				subj21=sc.nextInt();
				
				if(subj21>100 || subj21<0)
					throw new AvgExc("Number is invalid");
				System.out.println("Enter English mark");
				subj22=sc.nextInt();
				if(subj22>100 || subj22<0)
					throw new AvgExc("Number is invalid");
				System.out.println("Enter Science mark");
				subj23=sc.nextInt();
				if(subj23>100 || subj23<0)
					throw new AvgExc("Number is invalid");
				System.out.println("Average of first Student is: "+((subj11+subj12+subj12)/3));
				System.out.println("Average of Second Student is: "+((subj21+subj22+subj23)/3));
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
}

