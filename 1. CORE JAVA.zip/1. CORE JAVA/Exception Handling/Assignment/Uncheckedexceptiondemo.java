import java.util.Scanner;
class ThrowsD
{
	void show() throws ArrayIndexOutOfBoundsException,ArithmeticException,NullPointerException
	{	
	}	
}
class Uncheckedexceptiondemo
{
	public static void main(String args[])
	{
		ThrowsD td = new ThrowsD();
		
		try
		{
			td.show();
			//ArrayIndexOutOfBoundException
			Scanner sc=new Scanner(System.in);
			System.out.println("no of elements in array");
			int a=sc.nextInt();
			int arr[]=new int[a];
			System.out.println("elements of array");
			for(int i=0;i<a;i++)
				arr[i]=sc.nextInt();
			System.out.println("enter the index");
			int idx=sc.nextInt();
			System.out.println("the value of index is:"+arr[idx]);
			
			//ArithmaticException
			System.out.println("enter two numbers");
			int num1=sc.nextInt();
			int num2=sc.nextInt();
			int num3;
			num3=num1/num2;
			System.out.println(num3);
			
			//NullPointerException
			System.out.println("enter the string");
			String s=sc.next();
			//String s=null; //it will show NullPointerException
			System.out.println(s.length());
			
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("java.lang.ArrayIndexOutOfBoundsException");
		}
		catch(ArithmeticException e)
		{
			e.printStackTrace();
		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
		}
		System.out.println("done successfully");
	}
}
