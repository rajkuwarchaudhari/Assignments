import java.util.Scanner;
class ExceptionAssignment1
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter an Integer");
		String s=sc.nextLine();
		try
		{
			int num1=Integer.parseInt(s);
			System.out.println(num1*num1);
		}
		catch(Exception e)
		{
			System.out.println("Entered input in not a valid format for an integer");
		}
	}
}