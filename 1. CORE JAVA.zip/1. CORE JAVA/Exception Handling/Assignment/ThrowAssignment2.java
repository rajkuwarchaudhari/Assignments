import java.util.Scanner;
class InvalidRegistration extends RuntimeException
{
	InvalidRegistration(String a)
	{
		super(a);
	}
}
class ThrowAssignment2
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
			System.out.println("enter userName");
			String userName=sc.nextLine();
			System.out.println("enter userCountry");
			String userCountry=sc.next();
			registerUser(userName,userCountry);
			
	}
			
			
			public static void registerUser(String userName,String userCountry)
			{
				try
				{
					if(userCountry.equals("India"))
					{
						System.out.println("user registered successfully done");
				
					}
				else
					{
					throw new InvalidRegistration("User outside india cannot be reisterd");
					}
				}
				catch(InvalidRegistration e)
					{
					System.out.println(e);
				}
				System.out.println("last");
			}
}

			
		