import java.util.Scanner;
class ArithmaticFinally extends RuntimeException
{
	ArithmaticFinally(String a)
	{
		super(a);
	}
}
class ThrowAssignment3
{
	public static void main(String ags[])
	{
		Scanner sc=new Scanner(System.in);
		try{
			System.out.println("enter First number");
			int num1=sc.nextInt();
			System.out.println("enter Second number");
			int num2=sc.nextInt();
			int num3=num1/num2;
			System.out.println(num3);
			
		}
		catch(ArithmaticFinally e)
		{
			throw new ArithmaticFinally("you are diving the number 0 zero-Arithmatic exception occurs");
			
		}
		finally
		{
			System.out.println("You're inside finally block");
		}
	}
}
