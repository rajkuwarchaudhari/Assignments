import java.io.FileInputStream;
import java.io.FileNotFoundException;

class ThrowsD
{
	void show() throws FileNotFoundException
	{
		FileInputStream fs=new FileInputStream("d:/yash.xyz.txt");
	}
	void display() throws ClassNotFoundException
	{
		Class.forName("com.automobile.twowheeler");
	}
}
class Checkedexceptiondemo
{
	public static void main(String args[])
	{
		ThrowsD t=new ThrowsD();
		try
		{
			
			
			//FileNotFoundException
			t.show();
			
			//ClassNotFoundException
			t.display();
		
		
		}
		catch(FileNotFoundException e)
		{
			System.out.println(e);
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		System.out.println("done");
	}
}
