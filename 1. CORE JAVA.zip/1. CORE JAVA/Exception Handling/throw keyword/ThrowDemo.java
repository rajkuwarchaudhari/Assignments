import java.util.Scanner;
class VoteEligiblity extends RuntimeException
{
	VoteEligiblity(String a)
	{
		super(a);
	}
}
class ThrowDemo
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your age");
		int age=sc.nextInt();
		try
		{
			if(age<18)
			{
				throw new VoteEligiblity("ohh you are not eligible for voting");
				//System.out.println("after throw");//gives error bcoz we cant write any statements after throw statement
			}
			else
			{
				System.out.println("you are eligible");
			}
		}
		catch(VoteEligiblity e)
		{
			e.printStackTrace();
		}
		System.out.println("normal termination");
	}
}

			