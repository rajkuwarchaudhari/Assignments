import java.io.IOException;

class ThrowsD
{
	void show() throws IOException
	{
		 System.out.println("performing operations");
		
	}	
}
class ThrowsDemo1
{
	public static void main(String args[])
	{
		ThrowsD td = new ThrowsD();
		try
		{
			td.show();
		}
		catch(IOException e)
		{
			e.printStackTrace();
			
		}
		System.out.println("Hello Normal Termination");
		
	}

}