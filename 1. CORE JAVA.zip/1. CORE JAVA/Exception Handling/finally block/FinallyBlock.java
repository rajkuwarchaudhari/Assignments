class FinallyBlock
{
	public static void main(String args[])
	{
		try
		{
			int a=20,b=0,c;
			c=a/b;
			System.out.println(c);
		}
		catch(Exception e)
		{
			//e.printStackTrace();
			//System.out.println(e);
			System.out.println(e.getMessage());
			
		}
		finally
		{
			System.out.println("this will definately print whether the exception is handled or not");
		}
	}
}
