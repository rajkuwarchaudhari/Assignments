class CommandLine{
	
	public static void main(String args[]){
		int a=Integer.parseInt(args[0]);
		Float b=Float.parseFloat(args[1]);
		Double c=Double.parseDouble(args[2]);
		
		System.out.println("a=" + a + "b=" + b+ "c=" + c);
	}
}
