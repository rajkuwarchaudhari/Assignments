class A
{
	void animal()
	{
		System.out.println("In A class the animal is Dog");
	}
}
class B extends A
{
	void bird()
	{
		System.out.println("In B class the bird is Crow");
	}
}
class HierarchialLevelInheritance extends A
{
	void run()
	{
		System.out.println("main class is running");
	}
	public static void main(String [] args)
	{
		HierarchialLevelInheritance obj1=new HierarchialLevelInheritance();
		obj1.animal();
		obj1.run();
		B obj2= new B();
		obj2. bird();
		//obj2.run();// error because we didn't inherit the properties of B in main class
		obj2.animal();
	}
}
