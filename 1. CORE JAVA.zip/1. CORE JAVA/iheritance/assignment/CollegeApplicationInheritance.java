class Person
{
	String name;
	String dob;
	public Person(String name, String dob)
	{
	  this.name = name;
	  this.dob = dob;
	}
	void display()
	{
		System.out.println(name+" "+dob);
	}
}
class Teacher extends Person
{
	double salary;
	String subject;
	public Teacher(String name, String dob,double salary, String subject)
	{
		super(name,dob);
		this.salary=salary;
		this.subject=subject;
		
	}
	void display()
	{
		System.out.println(name+" "+dob+" "+salary+" "+subject);
	}
}
class Student extends Person
{
	int stu_id;
	public Student(String name, String dob, int stu_id)
	{
		super(name,dob);
		this.stu_id=stu_id;
	}
	void display()
	{
		System.out.println(name+" "+dob+" "+" "+stu_id);
	}
}
class CollegeStudent extends Student
{
	String college;
	int year;
	CollegeStudent(String name, String dob, int stu_id ,String college,int year)
	{
		super(name,dob,stu_id);
		this.college=college;
		this.year=year;
	}
	void display()
	{
		System.out.println(name+" "+dob+" "+stu_id+" "+college+" "+year);
	}
}

class CollegeApplicationInheritance
{
	public static void main(String args[])
	{
		Person p=new Person("raj" , "23/09/1998");
		Student s=new Student("raj" , "23/09/1998",101);
		Teacher t= new Teacher("raj" , "23/09/1998",15000, "java");
		CollegeStudent ca=new CollegeStudent("raj" , "23/09/1998", 101, "iet davv", 2022);
		p.display();
		s.display();
		t.display();
		ca.display();
	}
}