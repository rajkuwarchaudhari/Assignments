class Animal 
{
    public void eat()
    {
        System.out.println("Animal is eating");

    }
    public void sleep()
    {
        System.out.println("Animal is sleeping");

    }

}
class Bird extends Animal
{
    public void eat() //overide method
	{
        System.out.println("overide Animal eat method");
    }
    public void sleep() //overidemethod
	{
        System.out.println("override Animal sleep method");
    }

    public void fly()
    {
        System.out.println("Bird is flying");

    }
}
class AnimalInheritance{
    public static void main(String[] args) {
        Animal obj =new Animal();
		obj.eat();
        obj.sleep();
        Bird obj1 = new Bird();
        obj1.eat();
        obj1.sleep();
        obj1.fly();
    }
}

	