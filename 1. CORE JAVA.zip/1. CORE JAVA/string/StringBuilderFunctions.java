class StringBuilderFunctions
{
	public static void main(String args[])
	{
		String a= "Trainee";
		String b= "TRAINEE";
		String c= "Yash Technologies";
		
		System.out.println(a.isEmpty());
		
		System.out.println(c.trim());
		
		System.out.println(a.equals(b));
		
		System.out.println(b.equalsIgnoreCase(c));
		System.out.println(a.equalsIgnoreCase(b));
		
		System.out.println(a.compareTo(c));
		System.out.println(b.compareToIgnoreCase(c));
		
		System.out.println(c.substring(1,7));
		
	}
}

		
