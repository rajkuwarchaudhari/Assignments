class StringBufferFunctions
{
	public static void main(String args[])
	{
		StringBuffer sb=new StringBuffer("Welcome To The Yash Technologies");
		System.out.println(sb.deleteCharAt(4));
		StringBuffer sb1=new StringBuffer("Yash");
		StringBuffer sb2=new StringBuffer("Yash");
		System.out.println(sb1.equals(sb2)); //StringBuffer does not override equals method of object class
		System.out.println(sb.indexOf("e"));
		System.out.println(sb.lastIndexOf("e"));
		System.out.println(sb.insert(0,"hey "));
		System.out.println(sb.replace(0,6,"Jay "));
		//System.out.println(sb.reverse());
		System.out.println(sb.subSequence(2,6));
		System.out.println(sb.deleteCharAt(4));
		sb.setCharAt(8,'y');
		System.out.println(sb);
		sb.ensureCapacity(50);
		System.out.println(sb.capacity());
		sb.append("i am here");
		sb.trimToSize();
		System.out.println(sb.capacity());
		String s=new String("hello hey");
		s.concat("Jaynam Sir");
		System.out.println(s);
		
		
		
		
	}
}
