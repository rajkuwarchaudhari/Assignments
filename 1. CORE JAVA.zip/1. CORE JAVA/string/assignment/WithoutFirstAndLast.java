import java.util.Scanner;
class WithoutFirstAndLast
{
 public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the string:");
	String s1=sc.nextLine();
	
		if(s1.length()>1)
		System.out.println(s1.substring(1,s1.length()-1));
	
        else
        System.out.println("String length should be atleast 2");
}}