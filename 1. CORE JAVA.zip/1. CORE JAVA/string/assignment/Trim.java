import java.util.Scanner;
class Trim
{
 public static void main(String args[])
{
 Scanner sc=new Scanner(System.in);
 System.out.println("Enter the string:");
 String name=sc.nextLine();
System.out.println(name.trim());}}