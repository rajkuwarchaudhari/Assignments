class ThreadInterrupt extends Thread
{
	public void run()
	{
		//System.out.println(Thread.interrupted());true--> false--> false
		//System.out.println(Thread.interrupted());
		//System.out.println(Thread.interrupted());
		//System.out.println(Thread.currentThread().isInterrupted()); true--> true--> true
		//System.out.println(Thread.currentThread().isInterrupted());
			for(int i=1;i<=3;i++)
			{
				try
				{
					System.out.println(i);
					//System.out.println(Thread.interrupted());//1 true 2 false 3 false
					Thread.sleep(1000);
					//System.out.println(Thread.interrupted()); // 1 Intruptedexception 2 false 3 false
				}
				catch(Exception e)
				{
					//System.out.println(Thread.interrupted());// 1 false exception 2 3
					e.printStackTrace();
					//System.out.println(Thread.interrupted());//1 exception false  2 3
				}
				//System.out.println(Thread.interrupted());// 1 exception false 2 false 3 false
			}
	}
	public static void main(String args[])
	{
		ThreadInterrupt td=new ThreadInterrupt();
		td.start();
		td.interrupt();
	}
}
