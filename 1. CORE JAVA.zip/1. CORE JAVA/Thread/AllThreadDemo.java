public class AllThreadDemo extends Thread
{
    public void run()
	{
		Thread.currentThread().setName("RUN");
	    System.out.println("Run: "+Thread.currentThread().getName());
	}
	public static void main(String[] args)
	{
		System.out.println("Run: "+Thread.currentThread().getName());
		try
		{
			for(int i=1;i<=8;i++)
			{
				Thread.sleep(6000);
				System.out.println(i);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		AllThreadDemo t1=new AllThreadDemo();
		System.out.println(t1.isAlive());
		t1.setName("T1 thread is running");
		t1.start();
		System.out.println(t1.isAlive());
		System.out.println(Thread.currentThread().isAlive());
		System.out.println(Thread.currentThread().getPriority());
		Thread.currentThread().setPriority(MIN_PRIORITY);
		AllThreadDemo t2=new AllThreadDemo();
		t2.setPriority(5);
		t2.setName("T2 thread is running");
		t2.setDaemon(true);
		t2.start();
	}
}