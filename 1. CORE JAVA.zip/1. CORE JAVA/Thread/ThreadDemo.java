//multiple task multple thread
class Thread1 extends Thread
{
	public void run()
	{
		System.out.println("thread 1 is running");
	}
}
class Thread2 extends Thread
{
	public void run()
	{
		System.out.println("thread 2 is running");
	}
}
class Thread3 extends Thread
{
	public void run()
	{
		System.out.println("thread 3 is running");
	}
}
public class ThreadDemo
{
	public static void main(String args[])
	{
		Thread1 t1=new Thread1();
		t1.start();
		Thread2 t2=new Thread2();
		t2.start();
		Thread3 t3=new Thread3();
		t3.start();
	}
}
		