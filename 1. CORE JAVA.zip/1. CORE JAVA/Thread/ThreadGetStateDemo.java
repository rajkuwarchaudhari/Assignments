public class ThreadGetStateDemo extends Thread 
{  
   public void run()   
    {  
        
        Thread.State s = Thread.currentThread().getState();  
        System.out.println("the nameof running thread: "+ Thread.currentThread().getName());  
        System.out.println("the state of thread: " + s);  
    }  
    public static void main(String args[])   
    {  
        ThreadGetStateDemo t1 = new ThreadGetStateDemo();  
		ThreadGetStateDemo t2 = new ThreadGetStateDemo();
		ThreadGetStateDemo t3 = new ThreadGetStateDemo();
        
        t1.start();     
        t2.start();  
		t3.start();
    }  
}  