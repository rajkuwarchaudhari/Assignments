class TwoSmallLarArr
{
	public static void main(String args[])
	{
		int[] a={2,4,6,5,8,9,7};
		int small=a[0];
		int small2=a[1];
		int large=a[0];
		int large2=a[1];
		int temp=0;
		if(large<large2)
		{
			temp=large;
			large=large2;
			large2=temp;
		}
		for(int i:a)
		{
			if(i>large)
			{
				large2=large;
				large=i;
			}
		}
		if(small>small2)
		{
			temp=large;
			small=small2;
			small2=temp;
		}
		for(int i:a)
		{
			if(i<small){
				small2=small;
				small=i;
			}
		}
		
		System.out.println(large);
		System.out.println(large2);
		
		System.out.println(small);
		System.out.println(small2);
	}
}
		
