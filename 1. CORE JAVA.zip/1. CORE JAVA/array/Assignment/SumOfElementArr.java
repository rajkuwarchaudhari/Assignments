class SumOfElementArr
{
	public static void main(String args[])
	{
		int[] a={10,3,6,1,2,7,9};
		int sum=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==6)
				
			{
				for(int j=i+1;j<a.length;j++)
				{
					i=j;
				continue;
				}
			}
			sum+=a[i]; 
		
		}
		System.out.println(sum);
	}
}