class SumAvgArr
{
	public static void main(String args[])
	{
		//1-d array
		int sum=0;
		int[] a={10,20,30};
		for(int i=0;i<a.length;i++){
			sum=sum+a[i];
		}
		System.out.println(sum);
		double avg=(sum/a.length);
		System.out.println(avg);
	
	//2-d array
       /* int sum=0;
		int[][] a={{10,20,30},{40,50}};
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				sum=sum+a[i][j];
			}
			System.out.println(sum);
		    double avg=(sum/a.length);
		    System.out.println(avg);
		}*/
	}
}



		