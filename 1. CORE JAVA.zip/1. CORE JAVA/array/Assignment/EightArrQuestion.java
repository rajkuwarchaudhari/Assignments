class EightArrQuestion
{
	public static void main(String args[])
	{
		int i,k=0;
		int[] a={1,4,1,4};
		for(i=0;i<a.length;i++)
		{
			if(a[i]==1 || a[i]==4)
				k++;
		}
		if(k==a.length)
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
	}
}