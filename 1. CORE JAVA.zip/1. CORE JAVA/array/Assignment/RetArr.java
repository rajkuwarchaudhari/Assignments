class RetArr
{
	public static void main(String args[])
	{
		//int[][] a={{10,20,30},{40,50},{60,70,80}};
		//System.out.println(a);
		//System.out.println(a[0]);
		//System.out.println(a[0][0]);
		//System.out.println(a[1].length);
		
		int[][] a=new int[2][];
		a[0]=new int[3];
		a[1]=new int[2];
		//a[2]=new int[3];
		System.out.println(a);
		System.out.println(a[0]);//null
		//System.out.println(a[0][0]);//nullpointer error runtime
		System.out.println(a.length);//2
		//System.out.println(a[0][0].length);//error:compiletime
	}
}
