class IndexArr
{
	public static void main(String args[])
	{
		int[] a ={2,3,4,5,6,7};
		int b=0,c=0;
		int n=Integer.parseInt(args[0]);
		for(int i:a){
			c++;
			if(i==n){
				System.out.println(c);
				b++;
			}
		}
		if(b==0)
		System.out.println("-1");
	}
}
				