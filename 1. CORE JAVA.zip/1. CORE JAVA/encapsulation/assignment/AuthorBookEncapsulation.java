class Author
{
	private String n;
	private String e;
	private char g;
	
	public Author(String n, String e, char g) 
	{
		this.n = n;
		this.e = e;
		this.g = g;
	}

	public String getName() {
		return n;
	}

	public String getEmail() {
		return e;
	}

	public char getGender() {
		return g;
	}
	public String toString() {
		return "[name=" + n + ", email=" + e + ", gender=" + g + "]";
	}
}
class Book
{
	private String n;
	private Author a;
	private double p;
	private int qty;
	
	public Book(String n, Author a, double p, int qty)
	{
		this.n = n;
		this.a = a;
		this.p = p;
		this.qty = qty;
	}

	public double getPrice() {
		return p;
	}

	public void setPrice(double p) {
		this.p = p;
	}

	public int get() {
		return qty;
	}

	public void setQtyInStock(int qty) {
		this.qty = qty;
	}

	public String getName() {
		return n;
	}

	public Author getAuthor() {
		return a;
	}
	public String toString() {
		return "[name of book=" + n + ", About author=" + a + ", price=" + p + ", qtyInStock=" + qty + "]";
	}
}
class AuthorBookEncapsulation
{
	public static void main(String[] args) {
		Author obj = new Author("Rajkuwar", "xyz.com", 'f');
		Book obj1 = new Book("abc", obj, 345, 2);
		
		System.out.println(obj1);
	}
}