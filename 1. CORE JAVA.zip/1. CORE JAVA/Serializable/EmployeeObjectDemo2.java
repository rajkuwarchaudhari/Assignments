import java.io.*;
class Employee implements Serializable
{
 int empId;
 String empName;
 
  Employee(int empId, String empName)
  {
   this.empId=empId;
   this.empName= empName;
  }
  
  public String toString()
  {
  return empId+ "  " +empName;
  }
}
class EmployeeObjectDemo2
{
public static void main(String args[]) throws Exception
{
 //Employee e= new Employee(33,"Ajay");
 //System.out.println(e);
 
 File f= new File("D:/yash/yash.ser");
  ObjectInputStream ois= new ObjectInputStream(new FileInputStream(f));
  Employee e= (Employee)ois.readObject();
  ois.close();
  System.out.println(e);
  
}
}