import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexSplit
{
    public static void main(String[]args) 
	{
		Scanner sc=new Scanner(System.in);
		String s;
		System.out.println("any string");
		s=sc.next();
		String[] s1 = s.split("^[\\r?\\n|\\r]+$");
		for (String t : s1) 
		{
			System.out.println(t);
		}
	}
}