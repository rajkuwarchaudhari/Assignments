import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexAssignment 
{
    public static void main(String[]args) 
	{
		Scanner sc=new Scanner(System.in);
		String s,str,s2,date;
		System.out.println("enter Mobile no");
		s=sc.next();
        Pattern p = Pattern.compile("^[6 7 8 9][0-9]{9}$");// phone number
        Matcher m = p.matcher(s);
		
		
		System.out.println("enter email if");
		str=sc.next();
		Pattern p1 = Pattern.compile("^[\\w_\\-\\.]+[@][a-z]+[\\.][a-z]{2,3}$");// email
        Matcher m1 = p1.matcher(str);
		
		
		System.out.println("enter url");
		s2=sc.next();
		Pattern p2 = Pattern.compile("^(https?|ftp|file)://[-\\w+ & @ # /% ? = ~ _ |!:,.;]*[-\\w+&@#/%=~_|]$");
        Matcher m2 = p.matcher(s2);
		
		System.out.println("enter DOB in mm/dd/yy, mm/dd/yyyy, dd/mm/yy and dd/mm/yyyy");
		date=sc.next();
        Pattern p3 = Pattern.compile("^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$");// Date formate
        Matcher m3 = p3.matcher(date);
		
		
        if(m.find()) 
		{
            System.out.println("no is vaild: "+ m);
        }
		else
		{
			System.out.println("enter wrong number");
		}
		if(m1.find()) 
		{
            System.out.println("email is vaild: "+ m1);
        }
		else
		{
			System.out.println("enter wrong email");
		}
		if(m2.find()) 
		{
            System.out.println("URL is vaild: "+ m2);
        }
		else
		{
			System.out.println("enter wrong url");
		}
		if(m3.find())
		{
			System.out.println("the dob is correct"+date +" : "+ m3.matches());
		}
		else
		{
			System.out.println("enter wrong DOB");
		}
			
    }
}