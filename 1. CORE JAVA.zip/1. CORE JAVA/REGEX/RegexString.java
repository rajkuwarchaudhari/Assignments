import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexString 
{
    public static void main(String[]args) 
	{
		Scanner sc=new Scanner(System.in);
		String s;
		System.out.println("any string with numbers or not");
		s=sc.next();
        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher(s);
        while(m.find()) 
		{
            System.out.println("found the numbers: "+ m.group());
        }
    }
}